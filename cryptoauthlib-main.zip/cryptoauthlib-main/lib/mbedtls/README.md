mbedtls directory - Purpose
===========================
This directory contains the interfacing and wrapper functions to
integrate mbedtls as the software crypto library as well as provide
eliptic curve cryptography (ECC) hardware acceleration.

@ingroup atca_mbedtls_
