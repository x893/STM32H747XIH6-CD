#ifndef TEST_CERT_DEF_1_SIGNER_H
#define TEST_CERT_DEF_1_SIGNER_H

#include "atcacert/atcacert_def.h"

extern const uint8_t g_test_signer_1_ca_public_key[];
extern const atcacert_def_t g_test_cert_def_1_signer;

#endif
