#ifndef TEST_CERT_DEF_0_DEVICE_H
#define TEST_CERT_DEF_0_DEVICE_H

#include "atcacert/atcacert_def.h"

extern const atcacert_def_t g_test_cert_def_0_device;

#endif
